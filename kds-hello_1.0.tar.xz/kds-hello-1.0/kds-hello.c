#include <stdio.h>

int main(void) {
    printf("Капалбаев Дмитрий Сергеевич, группа 1-1\n");
    printf("Программа kds-hello успешно запущена.\n");
    return 0;
}
